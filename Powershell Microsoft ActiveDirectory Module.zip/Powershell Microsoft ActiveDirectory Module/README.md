# Powershell Microsoft ActiveDirectory Module

You can import this module using `Microsoft.ActiveDirectory.Management.dll` and other resources without local admin privileges or installing RSAT.

```
Import-Module .\Microsoft.ActiveDirectory.Management.dll
Import-Module .\ActiveDirectory\ActiveDirectory.psd1
```
